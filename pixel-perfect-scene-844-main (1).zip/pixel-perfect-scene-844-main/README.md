# Customizing This Portfolio

This portfolio is built so you can personalize everything from a handful of
files — no need to touch the design or animation code.

## Run locally

```bash
bun install
bun run dev
```

Then open the printed local URL (usually http://localhost:8080).

## Where to edit your content

| What | File |
| --- | --- |
| Name, wordmark, role, availability, email, social links | `src/data/site.ts` |
| Projects (add / edit / remove) | `src/data/projects.ts` |
| Skills (conveyor + categories) | `src/data/skills.ts` |
| Resume content (also powers the PDF download) | `src/data/resume.ts` |
| Hero headline / supporting statement | `src/routes/index.tsx` (hero section) |
| Biography, focus areas, timeline, philosophy | `src/routes/about.tsx` |
| Approach principles | `src/routes/index.tsx` (Approach section) |

Every placeholder is marked with a `TODO:` comment or the word "Placeholder".

## Adding or removing projects

1. Open `src/data/projects.ts`.
2. Copy an existing entry and change its `slug` (this becomes the URL:
   `/projects/<slug>`), title, copy, and fields.
3. Choose a `visual` treatment for the preview:
   - `orbit-product` — interactive 3D product scene (WebGL)
   - `tilt-browser` — 2.5D browser mockup that tilts with the cursor
   - `abstract-env` — interactive 3D abstract environment (WebGL)
   - `depth-layers` — layered 2.5D composition with scroll depth
4. Set `featured: true` to show it on the home page.
5. Delete an entry to remove the project and its detail page.

## Updating skills

Edit `src/data/skills.ts` — `conveyorRows` feed the two moving marquee rows,
`categories` feed the categorized lists on Home and About.

## Editing the resume

All resume content lives in `src/data/resume.ts`. The `/resume` page and the
**Download PDF** button are both generated from this single file — edit it
once and both stay in sync.

## Replacing the downloadable PDF

By default the PDF is generated in the browser from `src/data/resume.ts`, so
there is nothing to maintain. If you prefer to host a designed PDF instead:

1. Put your PDF at `public/resume/resume.pdf`.
2. In `src/routes/resume.tsx`, change the download button to
   `<a href="/resume/resume.pdf" download>` (and remove the generated-PDF
   handler).

## Replacing images and visuals

- Portrait: replace the placeholder composition inside `PortraitFrame` in
  `src/routes/about.tsx` with your photo.
- Hero mascot: the 3D scene is fully procedural in
  `src/components/hero/MascotScene.tsx` — swap the `Monolith` component for a
  `<primitive object={gltfScene} />` from a `.glb` placed in `public/models/`
  when you have one.
- Project previews: replace any treatment in
  `src/components/ProjectVisual.tsx` / `src/components/project-scenes/MiniScene.tsx`
  with your own screenshots, GLB models, or mockups.

## Connecting the contact form

The form currently opens the visitor's email client with the message
pre-filled (marked with a `TODO` in `src/routes/contact.tsx`). To send
messages directly, connect a form service or a server function at the marked
spot and remove the setup note shown under the button.

## Deploying

Publish from Lovable (or run `bun run build` and host the output anywhere
that serves static sites + server functions).
