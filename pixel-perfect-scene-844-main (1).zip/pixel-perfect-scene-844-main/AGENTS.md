<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

# Architecture & decisions

- All personalized content (name, projects, skills, resume, socials) lives in central files under `src/data/` — pages never hardcode personal details. Why: the user personalizes the site by editing data only.
- 3D scenes (`src/components/hero/MascotScene.tsx`, `src/components/project-scenes/MiniScene.tsx`) are client-only: lazy-imported inside `useEffect` behind a WebGL check, with CSS fallbacks rendered beneath. Why: SSR safety, graceful degradation, smaller initial bundle.
- Hero pointer/scroll input is shared via refs (`HeroStage`), read in `useFrame` — never via React state. Why: zero re-renders per frame.
- The resume PDF is generated client-side with jsPDF from `src/data/resume.ts` (`src/lib/resume-pdf.ts`); print styles in `src/styles.css` provide the print/save-as-PDF path. Why: one data source keeps page, PDF, and print in sync.
- TanStack route options order matters: define `loader` before `head` when head reads `loaderData` — reverse order collapses inference to `never`.
- Contact form has no backend: honeypot + time-trap + validation, then a mailto fallback; marked TODO for a real service.
- `src/types/r3f.d.ts` imports `@react-three/fiber` globally for JSX intrinsic elements (`<mesh>` etc.).
- Subdirectories keep their own AGENTS.md when scoped rules accumulate; read them before changing files there.
