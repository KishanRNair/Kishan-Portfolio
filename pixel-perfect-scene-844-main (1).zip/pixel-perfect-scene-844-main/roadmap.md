# Roadmap

## Portfolio build (Obsidian Espresso brief)

- [x] Design system (palette, typography, tokens) in src/styles.css
- [x] Central data files: site, projects, skills, resume
- [x] Routes: /, /projects, /projects/:slug, /about, /contact, /resume
- [x] Nav (scroll-reactive, active states, mobile menu) + footer + grain + cursor
- [x] Hero: procedural 3D mascot + smoke shader + CSS fallback
- [x] Home sections: intro, selected projects, skills conveyor, approach, CTA
- [x] Interactive project visuals (2.5D + WebGL variants) + category filter
- [x] Project detail template with prev/next navigation
- [x] About page with dimensional portrait frame
- [x] Contact form (validation, honeypot, time-trap, mailto fallback)
- [x] Resume page with PDF download (generated from data) + print styles
- [x] README customization guide
- [x] Visual verification in browser
